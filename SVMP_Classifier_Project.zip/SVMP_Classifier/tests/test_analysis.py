from analysis import parse_input,scan_motifs,align_one

def test_translation():
    assert parse_input('>x\nAUGGCCUAA','mRNA / CDS')[0]=='MA'
def test_protein():
    assert parse_input('>x\nMARGD','Protein')[0]=='MARGD'
def test_motif_positions():
    seq='AAAAHEAAHQQGQQHAAAARGD'
    m=scan_motifs(seq)
    assert any(x['match']=='RGD' and x['start']==20 for x in m)
def test_alignment():
    a=align_one('ACDEFGHIKLMNPQRSTVWY','ACDEFGHIKLMNPQRSTVWY')
    assert a['identity']==1 and a['query_coverage']==1
